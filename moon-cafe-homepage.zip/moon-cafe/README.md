# Moon Café — Homepage build

Static HTML / CSS / vanilla JS. No build step, no framework, no GSAP dependency.

| URL | File | Language |
|---|---|---|
| `/` | `index.html` | Arabic, RTL (default) |
| `/en/` | `en/index.html` | English, LTR |

## Run locally

Asset paths are root-relative (`/css/...`), so serve the folder as the web root:

```bash
cd moon-cafe
python3 -m http.server 8000
# open http://localhost:8000/ (AR) and http://localhost:8000/en/ (EN)
```

## What's implemented (homepage)

- Fixed header that turns compact and sticky on scroll. Nav links, active state and the gold Explore Menu CTA follow the mockup.
- Desktop Mega Menu: "Menu" still links to `/menu/`, and a chevron button opens the Drinks/Food panel with the 8 category links and an Explore Full Menu action. It opens on click, keyboard or hover, and closes on Escape or an outside click.
- Mobile/tablet drawer (≤999px): Home, Menu (Drinks/Food accordions, collapsed), Branches, Rewards, Contact.
- Interactive hero: a ribbon with category names scrolls along an SVG path and speeds up when you scroll. The three cups float and react to the pointer. The animation pauses when the hero is off-screen.
- About section: the statement includes the inline image pills and the gold highlight, followed by the CUP visual.
- Featured products carousel: loops, works with arrows, dots, swipe and the keyboard, and supports RTL. Content is static crawlable HTML.
- Branch preview cards (cream panel, directions pill, address and hours), plus See All Branches.
- Rewards section: 2 + cup + 2 layout and the Join CTA.
- Footer.
- A short preloader (capped at 900 ms), scroll reveals, and `prefers-reduced-motion` support. All content is visible without JS.
- Canonical, reciprocal `hreflang` (ar-SA / en / x-default), localized title and description, `lang`/`dir`.

## Deviations from the mockup (required by the docs)

1. **Hero Explore Menu CTA** is added below the cups (design.md §4.2, FR-20 require it inside the hero).
2. **Language switcher** (`عربي` / `English`) is added next to the header CTA (FR-03).
3. **Menu chevron** gives keyboard and touch access to the Mega Menu while "Menu" still opens `/menu/`.
4. **Gold** uses the Brand Manual `#DAAF67` rather than the slightly brighter yellow in the render (authority rule).

## ⚠️ Placeholders — release blockers

Everything below is marked in the HTML with `data-placeholder`, `data-pending` or `TODO`:

- **Images**: everything in `assets/images/placeholders/` is cropped from the low-resolution mockup (logo, cups, products, branch photos). Replace it with approved assets and the original SVG logo.
- **Fonts**: Proxima Nova and Helvetica Neue Arabic load only if they are installed locally. Add licensed `.woff2` files to `assets/fonts/` and uncomment the `url()` lines in `css/base.css`.
- **Content**: hero, about and rewards copy, product names and prices (`$` values from the mockup; currency TBD), branch names, addresses and hours. Arabic copy is a draft translation.
- **Links with no destination yet** (rendered without `href`): Get Directions ×2, Join Moon Rewards, Instagram, TikTok and Facebook.
- `og:image`, the favicon, and the final metadata copy.

## Not yet built

Menu, category, branches and contact pages (the nav already links to their routes), plus the product popup, `data/*.json`, `sitemap.xml`, `robots.txt` and `404.html`. Those wait for verified routes and content, per `seo-strategy.md`.

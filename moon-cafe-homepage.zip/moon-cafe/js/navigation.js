/* ==========================================================================
   Moon Café — navigation.js
   Sticky/compact header, desktop Mega Menu, mobile drawer + accordions.
   Works without GSAP; every link is a real <a href> so navigation never
   depends on this script (design.md §5, seo-strategy.md §4.4).
   ========================================================================== */
(function () {
  'use strict';

  var header = document.querySelector('[data-header]');

  /* ---- Sticky compact header ------------------------------------------- */
  if (header) {
    var ticking = false;
    var setCompact = function () {
      header.classList.toggle('is-compact', window.scrollY > 24);
      ticking = false;
    };
    window.addEventListener('scroll', function () {
      if (!ticking) { window.requestAnimationFrame(setCompact); ticking = true; }
    }, { passive: true });
    setCompact();
  }

  /* ---- Mega Menu --------------------------------------------------------- */
  var megaItem = document.querySelector('[data-mega]');
  if (megaItem) {
    var toggle = megaItem.querySelector('[data-mega-toggle]');
    var panel = megaItem.querySelector('[data-mega-panel]');
    var hoverTimer = null;
    var canHover = window.matchMedia('(hover: hover) and (pointer: fine)');

    var setOpen = function (open) {
      panel.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', String(open));
    };
    var isOpen = function () { return toggle.getAttribute('aria-expanded') === 'true'; };

    toggle.addEventListener('click', function () { setOpen(!isOpen()); });

    // Optional hover enhancement (design.md §5.1) — never the only way in.
    megaItem.addEventListener('mouseenter', function () {
      if (!canHover.matches) return;
      clearTimeout(hoverTimer);
      hoverTimer = setTimeout(function () { setOpen(true); }, 80);
    });
    megaItem.addEventListener('mouseleave', function () {
      if (!canHover.matches) return;
      clearTimeout(hoverTimer);
      hoverTimer = setTimeout(function () { setOpen(false); }, 180);
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && isOpen()) {
        setOpen(false);
        toggle.focus();
      }
    });
    document.addEventListener('click', function (e) {
      if (isOpen() && !megaItem.contains(e.target)) setOpen(false);
    });
    megaItem.addEventListener('focusout', function (e) {
      if (e.relatedTarget && !megaItem.contains(e.relatedTarget)) setOpen(false);
    });
  }

  /* ---- Mobile navigation -------------------------------------------------- */
  var navToggle = document.querySelector('[data-nav-toggle]');
  var mobileNav = document.querySelector('[data-mobile-nav]');
  if (navToggle && mobileNav) {
    var setMobile = function (open, returnFocus) {
      navToggle.setAttribute('aria-expanded', String(open));
      mobileNav.hidden = !open;
      document.body.classList.toggle('no-scroll', open);
      if (header) header.classList.toggle('is-menu-open', open);
      if (open) {
        var first = mobileNav.querySelector('a, button');
        if (first) first.focus();
      } else if (returnFocus) {
        navToggle.focus();
      }
    };

    navToggle.addEventListener('click', function () {
      setMobile(navToggle.getAttribute('aria-expanded') !== 'true');
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !mobileNav.hidden) setMobile(false, true);
    });
    // Same-page anchors (e.g. #rewards) should close the drawer.
    mobileNav.addEventListener('click', function (e) {
      var link = e.target.closest('a[href]');
      if (link) setMobile(false);
    });
    window.matchMedia('(min-width: 1000px)').addEventListener('change', function (mq) {
      if (mq.matches && !mobileNav.hidden) setMobile(false);
    });

    // Drinks / Food accordions start collapsed (design.md §8.1)
    mobileNav.querySelectorAll('[data-accordion]').forEach(function (btn) {
      var target = document.getElementById(btn.getAttribute('aria-controls'));
      btn.addEventListener('click', function () {
        var open = btn.getAttribute('aria-expanded') !== 'true';
        btn.setAttribute('aria-expanded', String(open));
        if (target) target.hidden = !open;
      });
    });
  }
})();
